class HiveTableConstant {
  HiveTableConstant._();

  static const int teamTableId = 0;
  static const String teamBox = 'teamBox';
}
