import 'package:mobile_application_project/features/auth/domain/entity/auth_entity.dart';

abstract interface class IAuthDataSource {
  Future<String> loginTeam(String teamName, String password);

  Future<void> registerTeam(AuthEntity student);

  Future<AuthEntity> getCurrentTeam();
}
